public class TrashBinActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TrashAdapter adapter;
    private NoteDao noteDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trash_bin);

        recyclerView = findViewById(R.id.recyclerViewTrash);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "notepad_db").allowMainThreadQueries().build();
        noteDao = db.noteDao();

        List<Note> deletedNotes = noteDao.getDeletedNotes();
        adapter = new TrashAdapter(deletedNotes, note -> {
            note.isDeleted = false;
            noteDao.update(note);
            refreshList();
        }, note -> {
            noteDao.delete(note);
            refreshList();
        });

        recyclerView.setAdapter(adapter);
    }

    private void refreshList() {
        adapter.updateList(noteDao.getDeletedNotes());
    }
}