@Dao
public interface NoteDao {

    @Query("SELECT * FROM Note WHERE isDeleted = 0")
    List<Note> getActiveNotes();

    @Query("SELECT * FROM Note WHERE isDeleted = 1")
    List<Note> getDeletedNotes();

    @Insert
    void insert(Note note);

    @Update
    void update(Note note);

    @Delete
    void delete(Note note);
}