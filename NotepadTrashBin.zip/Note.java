@Entity
public class Note {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String title;
    public String content;

    public boolean isDeleted;
}