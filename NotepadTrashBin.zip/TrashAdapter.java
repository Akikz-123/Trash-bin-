public class TrashAdapter extends RecyclerView.Adapter<TrashAdapter.ViewHolder> {

    private List<Note> noteList;
    private final OnNoteActionListener listener;

    public interface OnNoteActionListener {
        void onRestore(Note note);
        void onDelete(Note note);
    }

    public TrashAdapter(List<Note> noteList, OnNoteActionListener restoreListener, OnNoteActionListener deleteListener) {
        this.noteList = noteList;
        this.listener = new OnNoteActionListener() {
            @Override
            public void onRestore(Note note) {
                restoreListener.onRestore(note);
            }

            @Override
            public void onDelete(Note note) {
                deleteListener.onDelete(note);
            }
        };
    }

    @NonNull
    @Override
    public TrashAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_trash_note, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TrashAdapter.ViewHolder holder, int position) {
        Note note = noteList.get(position);
        holder.title.setText(note.title);
        holder.restore.setOnClickListener(v -> listener.onRestore(note));
        holder.delete.setOnClickListener(v -> listener.onDelete(note));
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public void updateList(List<Note> updatedNotes) {
        this.noteList = updatedNotes;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        Button restore, delete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.textNoteTitle);
            restore = itemView.findViewById(R.id.buttonRestore);
            delete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}